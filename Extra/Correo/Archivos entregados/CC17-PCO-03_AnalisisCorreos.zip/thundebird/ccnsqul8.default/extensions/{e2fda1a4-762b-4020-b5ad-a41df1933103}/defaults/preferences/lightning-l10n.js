//@line 4 "/builds/slave/tb-rel-c-esr52-l64_rpk_3-00000/l10n/es-ES/calendar/lightning-l10n.js"

//@line 6 "/builds/slave/tb-rel-c-esr52-l64_rpk_3-00000/l10n/es-ES/calendar/lightning-l10n.js"

//@line 9 "/builds/slave/tb-rel-c-esr52-l64_rpk_3-00000/l10n/es-ES/calendar/lightning-l10n.js"
pref("calendar.week.start", 1);

//@line 12 "/builds/slave/tb-rel-c-esr52-l64_rpk_3-00000/l10n/es-ES/calendar/lightning-l10n.js"
pref("calendar.week.d0sundaysoff", true);
pref("calendar.week.d1mondaysoff", false);
pref("calendar.week.d2tuesdaysoff", false);
pref("calendar.week.d3wednesdaysoff", false);
pref("calendar.week.d4thursdaysoff", false);
pref("calendar.week.d5fridaysoff", false);
pref("calendar.week.d6saturdaysoff", true);

pref("general.useragent.locale", "es-ES");

//@line 23 "/builds/slave/tb-rel-c-esr52-l64_rpk_3-00000/l10n/es-ES/calendar/lightning-l10n.js"
pref("calendar.categories.names", "Aniversarios,Clientes,Competencia,Cumpleaños,Días libres,Estado,Favoritos,Festivos,Ideas,Llamadas,Miscelánea,Negocios,Personal,Problemas,Proyectos,Regalos,Reuniones,Seguimiento,Proveedores,Usuarios,Vacaciones,Viajes");
