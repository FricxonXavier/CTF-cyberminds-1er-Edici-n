# Archivo olvidado (Web - Easy)

Levanta el reto con:

docker-compose up

Luego visita:
http://localhost:5003

Revisa si existen archivos adicionales.
