from flask import Flask, request

app = Flask(__name__)

FLAG = "FIS{L0_0CULt0_NO_3S_S3GURO}"

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        is_admin = request.form.get("isAdmin", "false")
        if is_admin == "true":
            return f'''
            <h1>Acceso privilegiado</h1>
            <p>Has modificado datos del formulario.</p>
            <strong>{FLAG}</strong>
            '''
        else:
            return '''
            <h1>Acceso denegado</h1>
            <p>No tienes permisos suficientes.</p>
            '''
    return '''
    <h1>Formulario</h1>
    <form method="POST">
        <input type="hidden" name="isAdmin" value="false">
        <label>Nombre:</label>
        <input type="text" name="name">
        <button type="submit">Enviar</button>
    </form>
    '''

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
