# Template Hell (Web - Hard)

This challenge runs fully in localhost using Docker.

## How to run
docker compose up

Then open:
http://localhost:5000

The goal is to find the flag.