from flask import Flask, request, render_template_string
import os

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    name = request.form.get("name", "guest")
    template = f"""
    <html>
      <body>
        <h1>Hello {name}</h1>
        <form method="POST">
          <input type="text" name="name" placeholder="Your name">
          <button type="submit">Send</button>
        </form>
      </body>
    </html>
    """
    return render_template_string(template)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)