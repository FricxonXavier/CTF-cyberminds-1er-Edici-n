# Robots curioso (Web - Easy)

Levanta el reto con:

docker-compose up

Luego visita:
http://localhost:8080