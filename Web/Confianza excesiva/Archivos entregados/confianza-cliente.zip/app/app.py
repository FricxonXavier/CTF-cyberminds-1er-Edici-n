from flask import Flask, request, make_response

app = Flask(__name__)

FLAG = "FIS{N0_c0nfi3s_3n_N4DIe}"

@app.route("/")
def index():
    role = request.cookies.get("role", "user")

    if role == "admin":
        content = f'''
        <h1>Panel de administración</h1>
        <p>Has accedido con privilegios elevados.</p>
        <strong>{FLAG}</strong>
        '''
    else:
        content = '''
        <h1>Bienvenido</h1>
        <p>Acceso estándar.</p>
        <p>No tienes permisos para ver contenido sensible.</p>
        '''

    resp = make_response(content)
    if "role" not in request.cookies:
        resp.set_cookie("role", "user")
    return resp

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
