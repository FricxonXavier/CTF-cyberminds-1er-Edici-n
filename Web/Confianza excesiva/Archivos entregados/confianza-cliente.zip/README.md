# Confianza del Cliente (Web - Easy)

Levanta el reto con:

docker-compose up

Luego visita:
http://localhost:5001

Explora cómo el servidor decide qué mostrar.
